chmod 755 ai_initial_module.sh
chmod 777 ai_module_2.sh
chmod 777 ai_door_management_module.sh
./ai_initial_module.sh
